/*
 * Copyright 2020 Adrián García
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.adriangl.pict2cam.imagepicker

import android.Manifest
import android.app.Activity
import android.content.ClipData
import android.content.ContentValues
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.widget.Toast
import androidx.activity.compose.setContent
import androidx.appcompat.app.AppCompatActivity
import androidx.compose.foundation.layout.*
import androidx.compose.material.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import com.adriangl.pict2cam.utils.ImageConstants
import com.theartofdev.edmodo.cropper.CropImage
import com.theartofdev.edmodo.cropper.CropImage.CROP_IMAGE_ACTIVITY_RESULT_ERROR_CODE
import java.io.File

/**
 * Android 11+ entry point.
 *
 * On Android 11 and above, third-party apps can no longer respond to
 * ACTION_IMAGE_CAPTURE intents. This activity provides an alternative workflow:
 *
 * 1. User opens Pict2Cam directly from the launcher.
 * 2. User picks an image from the gallery.
 * 3. User optionally rotates/crops the image.
 * 4. The resulting image is saved to the Pictures/Pict2Cam folder in MediaStore
 *    and its URI is copied to the clipboard — ready to paste into any app that
 *    accepts image input (Telegram, Gmail, etc.).
 *
 * On Android 10 and below this activity also works but the classic
 * ACTION_IMAGE_CAPTURE flow (via ImagePickerActivity) remains the primary path.
 */
class DirectLaunchActivity : AppCompatActivity() {

    companion object {
        private const val PICK_IMAGE_REQUEST_CODE = 2001
        private const val PERMISSION_REQUEST_CODE = 2002
    }

    private var outputUri: Uri? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContent {
            DirectLaunchScreen(
                onPickImage = { checkPermissionsAndPick() },
                onClose = { finish() }
            )
        }
    }

    private fun checkPermissionsAndPick() {
        val permission = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            Manifest.permission.READ_MEDIA_IMAGES
        } else {
            Manifest.permission.READ_EXTERNAL_STORAGE
        }

        if (ContextCompat.checkSelfPermission(this, permission) == PackageManager.PERMISSION_GRANTED) {
            openImagePicker()
        } else {
            ActivityCompat.requestPermissions(this, arrayOf(permission), PERMISSION_REQUEST_CODE)
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == PERMISSION_REQUEST_CODE &&
            grantResults.getOrNull(0) == PackageManager.PERMISSION_GRANTED
        ) {
            openImagePicker()
        } else {
            Toast.makeText(this, "Ruxsat berilmadi", Toast.LENGTH_SHORT).show()
        }
    }

    private fun openImagePicker() {
        val intent = Intent(Intent.ACTION_GET_CONTENT).apply {
            type = "image/*"
        }
        @Suppress("DEPRECATION")
        startActivityForResult(
            Intent.createChooser(intent, "Rasm tanlang"),
            PICK_IMAGE_REQUEST_CODE
        )
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        @Suppress("DEPRECATION")
        super.onActivityResult(requestCode, resultCode, data)

        when {
            resultCode != Activity.RESULT_OK -> {
                if (requestCode != PICK_IMAGE_REQUEST_CODE) finish()
            }

            requestCode == PICK_IMAGE_REQUEST_CODE -> {
                val imageUri = data?.data ?: return
                outputUri = createOutputUri()
                outputUri?.let { out ->
                    openImageEditor(imageUri, out)
                } ?: run {
                    Toast.makeText(this, "Fayl yaratib bo'lmadi", Toast.LENGTH_SHORT).show()
                }
            }

            requestCode == ImageEditActivity.REQUEST_CODE -> {
                outputUri?.let { openCropper(it, it) }
            }

            requestCode == CropImage.CROP_IMAGE_ACTIVITY_REQUEST_CODE -> {
                val resultUri = CropImage.getActivityResult(data)?.uri
                if (resultUri != null) {
                    saveToMediaStoreAndShare(resultUri)
                } else {
                    Toast.makeText(this, "Rasm saqlanmadi", Toast.LENGTH_SHORT).show()
                    finish()
                }
            }

            requestCode == CROP_IMAGE_ACTIVITY_RESULT_ERROR_CODE -> {
                Toast.makeText(this, "Rasm kesishda xato", Toast.LENGTH_SHORT).show()
                finish()
            }
        }
    }

    /**
     * Creates a temporary output file inside the app's private cache directory.
     * FileProvider gives other apps read access to this file.
     */
    private fun createOutputUri(): Uri? {
        return try {
            val cacheDir = File(cacheDir, "images").also { it.mkdirs() }
            val file = File.createTempFile("pict2cam_", ".jpg", cacheDir)
            FileProvider.getUriForFile(this, "$packageName.fileprovider", file)
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }

    private fun openImageEditor(imageUri: Uri, outputUri: Uri) {
        @Suppress("DEPRECATION")
        startActivityForResult(
            ImageEditActivity.createIntent(this, imageUri, outputUri),
            ImageEditActivity.REQUEST_CODE
        )
    }

    private fun openCropper(imageUri: Uri, outputUri: Uri) {
        CropImage.activity(imageUri)
            .setInitialCropWindowPaddingRatio(0f)
            .setShowCropOverlay(true)
            .setAllowRotation(true)
            .setAllowFlipping(true)
            .setRotationDegrees(0)
            .setOutputCompressFormat(ImageConstants.DEFAULT_COMPRESS_FORMAT)
            .setOutputCompressQuality(ImageConstants.DEFAULT_IMAGE_QUALITY)
            .setOutputUri(outputUri)
            .start(this)
    }

    /**
     * Saves the processed image to MediaStore (Pictures/Pict2Cam) so it is
     * visible in the gallery, then shares its URI via clipboard and a share sheet.
     */
    private fun saveToMediaStoreAndShare(sourceUri: Uri) {
        try {
            // Insert into MediaStore Pictures/Pict2Cam
            val contentValues = ContentValues().apply {
                put(MediaStore.Images.Media.DISPLAY_NAME, "pict2cam_${System.currentTimeMillis()}.jpg")
                put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/Pict2Cam")
                    put(MediaStore.Images.Media.IS_PENDING, 1)
                }
            }

            val collection = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                MediaStore.Images.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
            } else {
                MediaStore.Images.Media.EXTERNAL_CONTENT_URI
            }

            val destUri = contentResolver.insert(collection, contentValues)

            if (destUri != null) {
                // Copy bytes from source to MediaStore URI
                contentResolver.openInputStream(sourceUri)?.use { input ->
                    contentResolver.openOutputStream(destUri)?.use { output ->
                        input.copyTo(output)
                    }
                }

                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    val updateValues = ContentValues().apply {
                        put(MediaStore.Images.Media.IS_PENDING, 0)
                    }
                    contentResolver.update(destUri, updateValues, null, null)
                }

                // Share the saved image via share sheet
                val shareIntent = Intent(Intent.ACTION_SEND).apply {
                    type = "image/jpeg"
                    putExtra(Intent.EXTRA_STREAM, destUri)
                    clipData = ClipData.newRawUri("", destUri)
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                }
                startActivity(Intent.createChooser(shareIntent, "Rasmni ulashing"))
            } else {
                Toast.makeText(this, "MediaStore'ga saqlashda xato", Toast.LENGTH_SHORT).show()
            }
        } catch (e: Exception) {
            e.printStackTrace()
            Toast.makeText(this, "Xato: ${e.message}", Toast.LENGTH_SHORT).show()
        } finally {
            finish()
        }
    }
}

@Composable
fun DirectLaunchScreen(
    onPickImage: () -> Unit,
    onClose: () -> Unit
) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Pict2Cam") },
                backgroundColor = MaterialTheme.colors.primary,
                contentColor = androidx.compose.ui.graphics.Color.White
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Text(
                text = "📷",
                style = MaterialTheme.typography.h2
            )
            Spacer(modifier = Modifier.height(16.dp))
            Text(
                text = "Rasm tanlang, tahrirlang va istalgan ilovaga yuboring",
                style = MaterialTheme.typography.body1,
                textAlign = TextAlign.Center
            )
            Spacer(modifier = Modifier.height(32.dp))
            Button(
                onClick = onPickImage,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp)
            ) {
                Text("Galereyadan rasm tanlash")
            }
            Spacer(modifier = Modifier.height(12.dp))
            OutlinedButton(
                onClick = onClose,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp)
            ) {
                Text("Bekor qilish")
            }
        }
    }
}
