/*
 * Copyright 2020 Adrián García
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.adriangl.pict2cam.imagepicker

import android.app.Activity
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Matrix
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.widget.Toast
import androidx.activity.compose.setContent
import androidx.appcompat.app.AppCompatActivity
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.RotateLeft
import androidx.compose.material.icons.filled.RotateRight
import androidx.compose.material.icons.filled.Flip
import androidx.compose.material.icons.filled.Check
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.unit.dp
import com.adriangl.pict2cam.utils.ExifUtils
import com.adriangl.pict2cam.utils.ImageConstants
import java.io.OutputStream

/**
 * Activity that allows the user to rotate and flip an image before cropping.
 * Launched after image selection, before the crop step.
 */
class ImageEditActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_IMAGE_URI = "extra_image_uri"
        const val EXTRA_OUTPUT_URI = "extra_output_uri"
        const val REQUEST_CODE = 5678

        fun createIntent(
            activity: Activity,
            imageUri: Uri,
            outputUri: Uri
        ): Intent {
            return Intent(activity, ImageEditActivity::class.java).apply {
                putExtra(EXTRA_IMAGE_URI, imageUri)
                putExtra(EXTRA_OUTPUT_URI, outputUri)
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val imageUri = intent.getParcelableExtra<Uri>(EXTRA_IMAGE_URI)
        val outputUri = intent.getParcelableExtra<Uri>(EXTRA_OUTPUT_URI)

        if (imageUri == null || outputUri == null) {
            setResult(Activity.RESULT_CANCELED)
            finish()
            return
        }

        val originalBitmap = try {
            MediaStore.Images.Media.getBitmap(contentResolver, imageUri)
        } catch (e: Exception) {
            Toast.makeText(this, "Rasmni ochib bo'lmadi", Toast.LENGTH_SHORT).show()
            setResult(Activity.RESULT_CANCELED)
            finish()
            return
        }

        setContent {
            ImageEditScreen(
                originalBitmap = originalBitmap,
                onConfirm = { editedBitmap, rotationDegrees, flipHorizontal ->
                    saveBitmapToUri(editedBitmap, outputUri)
                    // Copy EXIF from original image to output, adjusting orientation tag
                    ExifUtils.copyExif(
                        contentResolver = contentResolver,
                        sourceUri = imageUri,
                        destUri = outputUri,
                        rotationDegrees = rotationDegrees,
                        flipHorizontal = flipHorizontal
                    )
                    setResult(Activity.RESULT_OK)
                    finish()
                },
                onCancel = {
                    setResult(Activity.RESULT_CANCELED)
                    finish()
                }
            )
        }
    }

    private fun saveBitmapToUri(bitmap: Bitmap, uri: Uri) {
        var outputStream: OutputStream? = null
        try {
            outputStream = contentResolver.openOutputStream(uri)
            bitmap.compress(
                ImageConstants.DEFAULT_COMPRESS_FORMAT,
                ImageConstants.DEFAULT_IMAGE_QUALITY,
                outputStream
            )
        } finally {
            outputStream?.close()
        }
    }
}

@Composable
fun ImageEditScreen(
    originalBitmap: Bitmap,
    onConfirm: (Bitmap, Float, Boolean) -> Unit,
    onCancel: () -> Unit
) {
    var rotationDegrees by remember { mutableStateOf(0f) }
    var flipHorizontal by remember { mutableStateOf(false) }

    val currentBitmap by remember(rotationDegrees, flipHorizontal, originalBitmap) {
        derivedStateOf {
            applyTransformations(originalBitmap, rotationDegrees, flipHorizontal)
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Rasmni tahrirlash") },
                backgroundColor = MaterialTheme.colors.primary,
                contentColor = Color.White
            )
        },
        bottomBar = {
            BottomAppBar(backgroundColor = MaterialTheme.colors.surface) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 8.dp),
                    horizontalArrangement = Arrangement.SpaceEvenly,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Chapga aylantirish
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        IconButton(onClick = { rotationDegrees = (rotationDegrees - 90f) % 360f }) {
                            Icon(
                                imageVector = Icons.Default.RotateLeft,
                                contentDescription = "Chapga aylantirish",
                                modifier = Modifier.size(32.dp)
                            )
                        }
                        Text("Chapga", style = MaterialTheme.typography.caption)
                    }

                    // O'ngga aylantirish
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        IconButton(onClick = { rotationDegrees = (rotationDegrees + 90f) % 360f }) {
                            Icon(
                                imageVector = Icons.Default.RotateRight,
                                contentDescription = "O'ngga aylantirish",
                                modifier = Modifier.size(32.dp)
                            )
                        }
                        Text("O'ngga", style = MaterialTheme.typography.caption)
                    }

                    // Gorizontal ag'darish
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        IconButton(onClick = { flipHorizontal = !flipHorizontal }) {
                            Icon(
                                imageVector = Icons.Default.Flip,
                                contentDescription = "Ag'darish",
                                modifier = Modifier.size(32.dp)
                            )
                        }
                        Text("Ag'darish", style = MaterialTheme.typography.caption)
                    }

                    // Tasdiqlash
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        IconButton(
                            onClick = { onConfirm(currentBitmap, rotationDegrees, flipHorizontal) },
                            modifier = Modifier
                                .background(
                                    color = MaterialTheme.colors.primary,
                                    shape = MaterialTheme.shapes.small
                                )
                        ) {
                            Icon(
                                imageVector = Icons.Default.Check,
                                contentDescription = "Tasdiqlash",
                                tint = Color.White,
                                modifier = Modifier.size(32.dp)
                            )
                        }
                        Text("Tayyor", style = MaterialTheme.typography.caption)
                    }
                }
            }
        }
    ) { paddingValues ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .background(Color.Black),
            contentAlignment = Alignment.Center
        ) {
            Image(
                bitmap = currentBitmap.asImageBitmap(),
                contentDescription = "Tahrirlash uchun rasm",
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
            )
        }
    }
}

private fun applyTransformations(
    source: Bitmap,
    rotationDegrees: Float,
    flipHorizontal: Boolean
): Bitmap {
    val matrix = Matrix()
    if (rotationDegrees != 0f) {
        matrix.postRotate(rotationDegrees)
    }
    if (flipHorizontal) {
        matrix.postScale(-1f, 1f, source.width / 2f, source.height / 2f)
    }
    return if (rotationDegrees == 0f && !flipHorizontal) {
        source
    } else {
        Bitmap.createBitmap(source, 0, 0, source.width, source.height, matrix, true)
    }
}
