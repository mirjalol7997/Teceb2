/*
 * Copyright 2020 Adrián García
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.adriangl.pict2cam.utils

import android.content.ContentResolver
import android.net.Uri
import androidx.exifinterface.media.ExifInterface

/**
 * Utility object for copying EXIF metadata between images.
 *
 * When a user selects an image and applies rotate/flip/crop, the output bitmap
 * loses all original EXIF data. This utility reads EXIF from the source URI and
 * writes it to the destination URI, updating the orientation tag to reflect any
 * rotation or flip the user applied.
 */
object ExifUtils {

    /**
     * All EXIF tags we want to copy from source to destination.
     * Orientation is excluded here because it is handled separately
     * based on the user's rotation/flip actions.
     */
    private val EXIF_TAGS_TO_COPY = arrayOf(
        ExifInterface.TAG_DATETIME,
        ExifInterface.TAG_DATETIME_DIGITIZED,
        ExifInterface.TAG_DATETIME_ORIGINAL,
        ExifInterface.TAG_MAKE,
        ExifInterface.TAG_MODEL,
        ExifInterface.TAG_SOFTWARE,
        ExifInterface.TAG_ARTIST,
        ExifInterface.TAG_COPYRIGHT,
        ExifInterface.TAG_IMAGE_DESCRIPTION,
        ExifInterface.TAG_USER_COMMENT,
        ExifInterface.TAG_GPS_LATITUDE,
        ExifInterface.TAG_GPS_LATITUDE_REF,
        ExifInterface.TAG_GPS_LONGITUDE,
        ExifInterface.TAG_GPS_LONGITUDE_REF,
        ExifInterface.TAG_GPS_ALTITUDE,
        ExifInterface.TAG_GPS_ALTITUDE_REF,
        ExifInterface.TAG_GPS_TIMESTAMP,
        ExifInterface.TAG_GPS_DATESTAMP,
        ExifInterface.TAG_GPS_SPEED,
        ExifInterface.TAG_GPS_SPEED_REF,
        ExifInterface.TAG_GPS_PROCESSING_METHOD,
        ExifInterface.TAG_EXPOSURE_TIME,
        ExifInterface.TAG_F_NUMBER,
        ExifInterface.TAG_ISO_SPEED_RATINGS,
        ExifInterface.TAG_FOCAL_LENGTH,
        ExifInterface.TAG_FLASH,
        ExifInterface.TAG_WHITE_BALANCE,
        ExifInterface.TAG_METERING_MODE,
        ExifInterface.TAG_EXPOSURE_MODE,
        ExifInterface.TAG_SCENE_CAPTURE_TYPE,
        ExifInterface.TAG_LIGHT_SOURCE,
        ExifInterface.TAG_SUBJECT_DISTANCE,
        ExifInterface.TAG_DIGITAL_ZOOM_RATIO,
        ExifInterface.TAG_COLOR_SPACE,
        ExifInterface.TAG_PIXEL_X_DIMENSION,
        ExifInterface.TAG_PIXEL_Y_DIMENSION
    )

    /**
     * Copies EXIF metadata from [sourceUri] to [destUri], then updates the
     * orientation tag to reflect the [rotationDegrees] (0, 90, 180, 270) and
     * [flipHorizontal] the user applied.
     *
     * @param contentResolver  Used to open streams for both URIs.
     * @param sourceUri        The original image selected by the user.
     * @param destUri          The output image after crop/rotate.
     * @param rotationDegrees  Clockwise rotation applied by the user (multiple of 90).
     * @param flipHorizontal   Whether the user flipped the image horizontally.
     */
    fun copyExif(
        contentResolver: ContentResolver,
        sourceUri: Uri,
        destUri: Uri,
        rotationDegrees: Float = 0f,
        flipHorizontal: Boolean = false
    ) {
        try {
            // Read EXIF from source
            val sourceStream = contentResolver.openInputStream(sourceUri) ?: return
            val sourceExif = ExifInterface(sourceStream)
            sourceStream.close()

            // Write EXIF to destination
            val destStream = contentResolver.openInputStream(destUri) ?: return
            val destExif = ExifInterface(destStream)
            destStream.close()

            // Copy all non-orientation tags
            for (tag in EXIF_TAGS_TO_COPY) {
                val value = sourceExif.getAttribute(tag)
                if (value != null) {
                    destExif.setAttribute(tag, value)
                }
            }

            // Compute new orientation based on original orientation + user rotation/flip
            val newOrientation = computeNewOrientation(
                sourceExif = sourceExif,
                rotationDegrees = rotationDegrees,
                flipHorizontal = flipHorizontal
            )
            destExif.setAttribute(
                ExifInterface.TAG_ORIENTATION,
                newOrientation.toString()
            )

            // Save to destination file
            val destSaveStream = contentResolver.openOutputStream(destUri, "rw") ?: return
            destExif.saveAttributes()
            destSaveStream.close()

        } catch (e: Exception) {
            // EXIF copy is best-effort; never crash the main image flow
            e.printStackTrace()
        }
    }

    /**
     * Computes the combined EXIF orientation value after applying
     * [rotationDegrees] and [flipHorizontal] on top of the original
     * orientation stored in [sourceExif].
     */
    private fun computeNewOrientation(
        sourceExif: ExifInterface,
        rotationDegrees: Float,
        flipHorizontal: Boolean
    ): Int {
        // Normalise rotation to 0/90/180/270
        val rotation = ((rotationDegrees % 360) + 360).toInt() / 90 * 90

        // Original orientation from source
        val originalOrientation = sourceExif.getAttributeInt(
            ExifInterface.TAG_ORIENTATION,
            ExifInterface.ORIENTATION_NORMAL
        )

        // Get base rotation from original EXIF orientation (ignoring flip for simplicity)
        val baseRotation = when (originalOrientation) {
            ExifInterface.ORIENTATION_ROTATE_90,
            ExifInterface.ORIENTATION_TRANSVERSE -> 90
            ExifInterface.ORIENTATION_ROTATE_180,
            ExifInterface.ORIENTATION_FLIP_VERTICAL -> 180
            ExifInterface.ORIENTATION_ROTATE_270,
            ExifInterface.ORIENTATION_TRANSPOSE -> 270
            else -> 0
        }

        val totalRotation = (baseRotation + rotation) % 360

        // Map combined rotation + flip back to an EXIF orientation constant
        return when {
            flipHorizontal && totalRotation == 0   -> ExifInterface.ORIENTATION_FLIP_HORIZONTAL
            flipHorizontal && totalRotation == 90  -> ExifInterface.ORIENTATION_TRANSVERSE
            flipHorizontal && totalRotation == 180 -> ExifInterface.ORIENTATION_FLIP_VERTICAL
            flipHorizontal && totalRotation == 270 -> ExifInterface.ORIENTATION_TRANSPOSE
            !flipHorizontal && totalRotation == 90  -> ExifInterface.ORIENTATION_ROTATE_90
            !flipHorizontal && totalRotation == 180 -> ExifInterface.ORIENTATION_ROTATE_180
            !flipHorizontal && totalRotation == 270 -> ExifInterface.ORIENTATION_ROTATE_270
            else -> ExifInterface.ORIENTATION_NORMAL
        }
    }
}
